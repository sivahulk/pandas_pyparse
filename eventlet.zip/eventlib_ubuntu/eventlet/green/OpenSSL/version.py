from OpenSSL.version import __version__, __doc__
